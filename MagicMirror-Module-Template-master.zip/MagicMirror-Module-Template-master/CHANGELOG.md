## [1.2.0] - 2017-07-21
- Use getStyles for module
- Include node 7 support
- Add test for ESLint, stylelint, jsonlint, markdownlint and js-yaml
- Include create CHANGELOG file

## [1.1.1] - 2017-04-02
- Fix missing files in project #4

## [1.1.0] - 2017-03-04
- Add example use translations
- Improvement configuration script and remote execution command
- Fix description assignment
- Set version by defaul 1.0.0 in template
- Documentation fix and improvement

## [1.0.0] - 2017-02-17

- First public release
